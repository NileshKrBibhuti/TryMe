// QuickTab Organizer v2.1.2 — local-only background worker; no page scripts or external services.
const KEY = "quicktabData";
const CAPTURE_MAX_AGE_MS = 10 * 60 * 1000;
let sequence = Promise.resolve();

function serial(task) {
  const current = sequence.then(task, task);
  sequence = current.catch(() => {});
  return current;
}
async function getData() {
  const record = await chrome.storage.local.get(KEY);
  const value = record[KEY];
  return {
    categories: Array.isArray(value?.categories) ? value.categories : [],
    capture: value?.capture || null,
    lastCategoryId: value?.lastCategoryId || null,
    pinnedCategoryIds: Array.isArray(value?.pinnedCategoryIds) ? value.pinnedCategoryIds : [],
    workspaces: Array.isArray(value?.workspaces) ? value.workspaces : [],
    undoHistory: Array.isArray(value?.undoHistory) ? value.undoHistory : []
  };
}
async function putData(data) { await chrome.storage.local.set({[KEY]: data}); }
function normalizeUrl(value) {
  if (typeof value !== "string") return null;
  try {
    const url = new URL(value);
    return url.protocol === "http:" || url.protocol === "https:" ? url.href : null;
  } catch { return null; }
}
function safeUrl(tab) { return normalizeUrl(tab?.url || tab?.pendingUrl) ? (tab.url || tab.pendingUrl) : null; }
function categoryById(data, id) {
  const cat = data.categories.find(c => c.id === id);
  if (!cat) throw new Error("Category not found.");
  return cat;
}
function existingCategoryIds(data) {
  return new Set(data.categories.map(cat => cat.id));
}
function validPinnedIds(data) {
  const valid = existingCategoryIds(data);
  return [...new Set(data.pinnedCategoryIds.filter(id => typeof id === "string" && valid.has(id)))];
}
function safeWorkspaceIds(data, ids) {
  const valid = existingCategoryIds(data);
  return [...new Set((Array.isArray(ids) ? ids : []).filter(id => typeof id === "string" && valid.has(id)))];
}
function workspaceById(data, id) {
  const workspace = data.workspaces.find(w => w.id === id);
  if (!workspace) throw new Error("Workspace not found.");
  return workspace;
}
function cleanCategoryReferences(data) {
  data.pinnedCategoryIds = validPinnedIds(data);
  data.workspaces = data.workspaces.map(workspace => ({
    ...workspace,
    categoryIds: safeWorkspaceIds(data, workspace.categoryIds)
  })).filter(workspace => workspace.categoryIds.length > 0);
}
// Deletions are recorded as compact, persistent undo entries, not whole-data snapshots.
// There is no arbitrary number-of-undos cap: every deleted item can be restored in
// reverse order, subject only to Chrome's normal local-storage capacity.
function rememberDeletion(data, entry) {
  data.undoHistory.push({ ...entry, deletedAt: Date.now() });
}
function insertAt(items, index, item) {
  const position = Number.isInteger(index) ? Math.max(0, Math.min(index, items.length)) : items.length;
  items.splice(position, 0, item);
}
function undoLastDeletion(data) {
  const entry = data.undoHistory.at(-1);
  if (!entry) throw new Error("Nothing left to undo.");
  let description;
  if (entry.kind === "link") {
    const cat = categoryById(data, entry.categoryId);
    if (!cat.links.some(link => link.url === entry.link?.url)) {
      insertAt(cat.links, entry.index, entry.link);
      description = "Saved link restored.";
    } else {
      description = "Link already present; no duplicate was added.";
    }
  } else if (entry.kind === "category") {
    const cat = entry.category;
    if (!cat || data.categories.some(other => other.id === cat.id)) {
      throw new Error("Cannot restore category: it already exists or history is invalid.");
    }
    insertAt(data.categories, entry.index, cat);
    if (entry.pinIndex >= 0 && !data.pinnedCategoryIds.includes(cat.id)) {
      insertAt(data.pinnedCategoryIds, entry.pinIndex, cat.id);
    }
    // Restore workspace membership removed when the category was deleted,
    // without reverting workspace edits or pins made after that deletion.
    for (const reference of (entry.workspaceRefs || [])) {
      const previous = reference.workspace;
      if (!previous || !Array.isArray(previous.categoryIds)) continue;
      const existing = data.workspaces.find(w => w.id === previous.id);
      if (existing) {
        if (existing.categoryIds.includes(cat.id)) continue;
        insertAt(existing.categoryIds, previous.categoryIds.indexOf(cat.id), cat.id);
      } else {
        insertAt(data.workspaces, reference.index, previous);
      }
    }
    if (entry.wasLastCategory && !data.lastCategoryId) data.lastCategoryId = cat.id;
    description = `Category "${cat.name}" restored with ${cat.links.length} links.`;
  } else if (entry.kind === "workspace") {
    const workspace = entry.workspace;
    if (!workspace || data.workspaces.some(w => w.id === workspace.id)) {
      throw new Error("Cannot restore workspace: it already exists or history is invalid.");
    }
    insertAt(data.workspaces, entry.index, workspace);
    description = `Workspace "${workspace.name}" restored.`;
  } else {
    throw new Error("Unknown undo history entry.");
  }
  data.undoHistory.pop();
  return { description, remaining: data.undoHistory.length };
}

function saveIntoCategory(data, categoryId, tabs) {
  const cat = categoryById(data, categoryId);
  let added = 0;
  let already = 0;
  let changed = false;
  const additions = [];
  const existingUrls = new Set(cat.links.map(link => link.url));
  for (const tab of tabs) {
    const url = safeUrl(tab);
    if (!url) continue;
    if (existingUrls.has(url)) {
      already++;
      const existing = cat.links.find(link => link.url === url) || additions.find(link => link.url === url);
      if (existing && tab.title && tab.title !== existing.title) {
        existing.title = String(tab.title).slice(0, 250); // Never modify optional customName.
        changed = true;
      }
    } else {
      additions.push({url, title: String(tab.title || url).slice(0, 250), addedAt: Date.now()});
      existingUrls.add(url);
      added++;
    }
  }
  // New links appear before old links. Batch additions retain their tab-strip order.
  if (additions.length) {
    cat.links.unshift(...additions);
    changed = true;
  }
  if (data.lastCategoryId !== categoryId) changed = true;
  data.lastCategoryId = categoryId;
  return {added, already, changed};
}
async function getBrowserWindow() {
  const win = await chrome.windows.getLastFocused({windowTypes: ["normal"]});
  if (!win || typeof win.id !== "number") throw new Error("No normal Chrome window found.");
  return win.id;
}
async function activeTab(windowId) {
  const tabs = await chrome.tabs.query({active: true, windowId});
  if (!tabs.length) throw new Error("No active tab found.");
  return tabs[0];
}
async function addActive(categoryId, goNext = false) {
  const windowId = await getBrowserWindow();
  const tab = await activeTab(windowId);
  if (!safeUrl(tab)) throw new Error("Open a normal http:// or https:// website first.");
  const data = await getData();
  const result = saveIntoCategory(data, categoryId, [tab]);
  await putData(data);
  if (goNext) {
    const list = (await chrome.tabs.query({windowId})).sort((a, b) => a.index - b.index);
    const eligible = list.filter(t => safeUrl(t));
    const pos = eligible.findIndex(t => t.id === tab.id);
    if (eligible.length > 1 && pos !== -1) {
      await chrome.tabs.update(eligible[(pos + 1) % eligible.length].id, {active: true});
    }
  }
  return result;
}
function reorder(items, sourceId, targetId, placement, key) {
  if (sourceId === targetId) return false;
  const from = items.findIndex(item => item[key] === sourceId);
  const target = items.findIndex(item => item[key] === targetId);
  if (from < 0 || target < 0) throw new Error("Cannot reorder: item no longer exists.");
  if (placement !== "before" && placement !== "after") throw new Error("Invalid drop position.");
  const [item] = items.splice(from, 1);
  const to = items.findIndex(candidate => candidate[key] === targetId);
  items.splice(to + (placement === "after" ? 1 : 0), 0, item);
  return true;
}

// Match canonical browser URLs, including their path, query string, and hash.
// This resolves default ports, host casing, and example.com vs example.com/.
async function openLinks(urls, activateSingle = false) {
  const valid = urls.map(url => ({url, key: normalizeUrl(url)})).filter(item => item.key);
  const requested = [];
  const seen = new Set();
  for (const item of valid) {
    if (!seen.has(item.key)) {seen.add(item.key); requested.push(item);}
  }
  if (!requested.length) return {requested: 0, opened: 0, existing: [], failed: []};

  const targetWindowId = await getBrowserWindow();
  // All accessible tabs, including other normal windows; no extra permissions needed.
  const [tabs, windows] = await Promise.all([
    chrome.tabs.query({}),
    chrome.windows.getAll({windowTypes: ["normal"]})
  ]);
  const windowNumbers = new Map(windows.map((win, index) => [win.id, index + 1]));
  const openByUrl = new Map();
  for (const tab of tabs) {
    const key = normalizeUrl(tab.url || tab.pendingUrl);
    if (!key) continue;
    const previous = openByUrl.get(key);
    // Prefer the tab from the current window when the same site is open in multiple windows.
    if (!previous || (tab.windowId === targetWindowId && previous.windowId !== targetWindowId)) {
      openByUrl.set(key, tab);
    }
  }
  const existing = [];
  const failed = [];
  let opened = 0;
  for (const item of requested) {
    const tab = openByUrl.get(item.key);
    if (tab) {
      existing.push({
        url: item.url,
        title: String(tab.title || item.url).slice(0, 250),
        tabId: tab.id,
        windowId: tab.windowId,
        tabIndex: tab.index + 1,
        windowNumber: windowNumbers.get(tab.windowId) || null
      });
      continue;
    }
    try {
      // Only a single-link action should steal focus; bulk opens stay in the background.
      const created = await chrome.tabs.create({windowId: targetWindowId, url: item.url, active: activateSingle});
      opened++;
      openByUrl.set(item.key, created);
    } catch (err) {
      failed.push({url: item.url, reason: err?.message || "Could not open tab."});
    }
  }
  let focused = false;
  if (activateSingle && existing.length === 1 && requested.length === 1) {
    const match = existing[0];
    try {
      await chrome.tabs.update(match.tabId, {active: true});
      await chrome.windows.update(match.windowId, {focused: true});
      focused = true;
    } catch {
      failed.push({url: match.url, reason: "Existing tab closed before it could be focused."});
    }
  }
  return {requested: requested.length, opened, existing, failed, focused};
}
async function focusExistingTab(tabId, expectedUrl) {
  if (!Number.isInteger(tabId) || !normalizeUrl(expectedUrl)) throw new Error("Invalid tab reference.");
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (!tab || normalizeUrl(tab.url || tab.pendingUrl) !== normalizeUrl(expectedUrl)) {
    throw new Error("This tab was closed or navigated away. Open the saved link again.");
  }
  await chrome.tabs.update(tab.id, {active: true});
  await chrome.windows.update(tab.windowId, {focused: true});
  return {focused: true};
}
async function doAction(msg) {
  const type = msg?.type;
  if (type === "getState") return {state: await getData()};
  if (type === "createCategory") {
    const name = String(msg.name || "").trim().slice(0, 65);
    if (!name) throw new Error("Enter a category name.");
    const data = await getData();
    const id = crypto.randomUUID();
    data.categories.push({id, name, links: []});
    data.lastCategoryId = id;
    await putData(data);
    return {state: data};
  }
  if (type === "renameCategory") {
    const data = await getData();
    const cat = categoryById(data, msg.id);
    const name = String(msg.name || "").trim().slice(0, 65);
    if (!name) throw new Error("Enter a category name.");
    cat.name = name;
    await putData(data);
    return {state: data};
  }
  if (type === "removeCategory") {
    const data = await getData();
    const index = data.categories.findIndex(c => c.id === msg.id);
    const cat = categoryById(data, msg.id);
    const workspaceRefs = data.workspaces.map((w, i) => ({
      index: i,
      workspace: {id: w.id, name: w.name, categoryIds: [...w.categoryIds]}
    })).filter(ref => ref.workspace.categoryIds.includes(msg.id));
    rememberDeletion(data, {
      kind: "category", category: cat, index,
      pinIndex: data.pinnedCategoryIds.indexOf(msg.id),
      wasLastCategory: data.lastCategoryId === msg.id,
      workspaceRefs
    });
    data.categories.splice(index, 1);
    cleanCategoryReferences(data); // Removing a category also cleans saved workspace references.
    if (data.capture?.categoryId === msg.id) data.capture = null;
    if (data.lastCategoryId === msg.id) data.lastCategoryId = null;
    await putData(data);
    return {state: data};
  }
  if (type === "undoDeletion") {
    const data = await getData();
    const result = undoLastDeletion(data);
    await putData(data);
    return {state: data, result};
  }
  if (type === "reorderCategory") {
    const data = await getData();
    if (reorder(data.categories, msg.sourceId, msg.targetId, msg.placement, "id")) await putData(data);
    return {state: data};
  }
  if (type === "setCategoryPinned") {
    const data = await getData();
    categoryById(data, msg.id);
    data.pinnedCategoryIds = validPinnedIds(data).filter(id => id !== msg.id);
    if (msg.pinned === true) data.pinnedCategoryIds.push(msg.id);
    else if (msg.pinned !== false) throw new Error("Invalid pin state.");
    await putData(data);
    return {state: data};
  }
  if (type === "clearPinnedCategories") {
    const data = await getData();
    data.pinnedCategoryIds = [];
    await putData(data);
    return {state: data};
  }
  if (type === "reorderPinnedCategory") {
    const data = await getData();
    data.pinnedCategoryIds = validPinnedIds(data);
    const list = data.pinnedCategoryIds.map(id => ({id}));
    if (reorder(list, msg.sourceId, msg.targetId, msg.placement, "id")) {
      data.pinnedCategoryIds = list.map(item => item.id);
      await putData(data);
    }
    return {state: data};
  }
  if (type === "createWorkspace") {
    const data = await getData();
    const name = String(msg.name || "").trim().slice(0, 65);
    if (!name) throw new Error("Enter a workspace name.");
    if (data.workspaces.length >= 100) throw new Error("Maximum 100 workspaces.");
    if (data.workspaces.some(w => w.name?.toLocaleLowerCase() === name.toLocaleLowerCase())) {
      throw new Error("A workspace with that name already exists.");
    }
    const ids = validPinnedIds(data);
    if (!ids.length) throw new Error("Pin at least one category first.");
    const workspace = {id: crypto.randomUUID(), name, categoryIds: ids};
    data.workspaces.push(workspace);
    await putData(data);
    return {state: data};
  }
  if (type === "activateWorkspace") {
    const data = await getData();
    const workspace = workspaceById(data, msg.id);
    data.pinnedCategoryIds = safeWorkspaceIds(data, workspace.categoryIds);
    if (!data.pinnedCategoryIds.length) throw new Error("This workspace has no remaining categories.");
    await putData(data);
    return {state: data};
  }
  if (type === "renameWorkspace") {
    const data = await getData();
    const workspace = workspaceById(data, msg.id);
    const name = String(msg.name || "").trim().slice(0, 65);
    if (!name) throw new Error("Enter a workspace name.");
    if (data.workspaces.some(w => w.id !== msg.id && w.name?.toLocaleLowerCase() === name.toLocaleLowerCase())) {
      throw new Error("A workspace with that name already exists.");
    }
    workspace.name = name;
    await putData(data);
    return {state: data};
  }
  if (type === "removeWorkspace") {
    const data = await getData();
    const index = data.workspaces.findIndex(w => w.id === msg.id);
    const workspace = workspaceById(data, msg.id);
    rememberDeletion(data, {kind: "workspace", workspace, index});
    data.workspaces.splice(index, 1);
    // Removing a saved workspace does not unpin categories already in use.
    await putData(data);
    return {state: data};
  }
  if (type === "renameLink") {
    const data = await getData();
    const cat = categoryById(data, msg.id);
    const link = cat.links.find(link => link.url === msg.url);
    if (!link) throw new Error("Saved link not found.");
    const name = String(msg.name || "").trim().slice(0, 250);
    if (name) link.customName = name;
    else delete link.customName; // Clearing the custom name restores the original website title.
    await putData(data);
    return {state: data};
  }
  if (type === "reorderLink") {
    const data = await getData();
    const cat = categoryById(data, msg.id);
    if (reorder(cat.links, msg.sourceUrl, msg.targetUrl, msg.placement, "url")) await putData(data);
    return {state: data};
  }
  if (type === "saveCurrent" || type === "saveAndNext") {
    return {result: await addActive(msg.id, type === "saveAndNext")};
  }
  if (type === "saveHighlighted") {
    const windowId = await getBrowserWindow();
    const tabs = await chrome.tabs.query({highlighted: true, windowId});
    const data = await getData();
    const result = saveIntoCategory(data, msg.id, tabs.sort((a, b) => a.index - b.index));
    await putData(data);
    return {result};
  }
  if (type === "startCapture") {
    const windowId = await getBrowserWindow();
    const tab = await activeTab(windowId);
    const data = await getData();
    categoryById(data, msg.id);
    data.capture = {categoryId: msg.id, windowId, startedAt: Date.now()};
    if (safeUrl(tab)) saveIntoCategory(data, msg.id, [tab]);
    await putData(data);
    return {state: data};
  }
  if (type === "stopCapture") {
    const data = await getData();
    data.capture = null;
    await putData(data);
    return {state: data};
  }
  if (type === "openAll" || type === "openSelected" || type === "openOne") {
    const data = await getData();
    const cat = categoryById(data, msg.id);
    let requested;
    if (type === "openAll") requested = cat.links.map(l => l.url);
    else if (type === "openOne") requested = cat.links.filter(l => l.url === msg.url).map(l => l.url);
    else {
      const selected = new Set(Array.isArray(msg.urls) ? msg.urls : []);
      requested = cat.links.filter(l => selected.has(l.url)).map(l => l.url);
    }
    if (type === "openOne" && !requested.length) throw new Error("Saved link not found.");
    return await openLinks(requested, type === "openOne");
  }
  if (type === "focusExisting") return await focusExistingTab(msg.tabId, msg.url);
  if (type === "removeLink") {
    const data = await getData();
    const cat = categoryById(data, msg.id);
    const index = cat.links.findIndex(l => l.url === msg.url);
    if (index === -1) throw new Error("Saved link not found.");
    rememberDeletion(data, {kind: "link", categoryId: cat.id, index, link: cat.links[index]});
    cat.links.splice(index, 1);
    await putData(data);
    return {state: data};
  }
  if (type === "importData") {
    const raw = msg.data;
    if (!raw || !Array.isArray(raw.categories) || raw.categories.length > 2000) throw new Error("Invalid QuickTab backup.");
    const oldToNewIds = new Map();
    const safeCats = raw.categories.map(c => {
      const seen = new Set();
      const links = [];
      for (const l of (Array.isArray(c?.links) ? c.links : []).slice(0, 2000)) {
        const url = l?.url;
        if (!normalizeUrl(url) || seen.has(url)) continue;
        seen.add(url);
        const link = {
          url,
          title: String(l.title || url).slice(0, 250),
          addedAt: Number.isFinite(l.addedAt) && l.addedAt > 0 ? l.addedAt : Date.now()
        };
        if (typeof l.customName === "string" && l.customName.trim()) {
          link.customName = l.customName.trim().slice(0, 250);
        }
        links.push(link);
      }
      const id = crypto.randomUUID();
      if (typeof c?.id === "string" && !oldToNewIds.has(c.id)) oldToNewIds.set(c.id, id);
      return {id, name: String(c?.name || "Imported").slice(0, 65), links};
    });
    const data = await getData();
    data.categories.push(...safeCats);
    // v2.1 backups also contain pin lists and workspaces. Remap imported IDs so
    // they refer to newly imported categories, never existing categories.
    if (Array.isArray(raw.pinnedCategoryIds)) {
      const importedPins = raw.pinnedCategoryIds.map(id => oldToNewIds.get(id)).filter(Boolean);
      data.pinnedCategoryIds = [...new Set([...validPinnedIds(data), ...importedPins])];
    }
    if (Array.isArray(raw.workspaces)) {
      for (const item of raw.workspaces.slice(0, 100)) {
        const ids = [...new Set((Array.isArray(item?.categoryIds) ? item.categoryIds : [])
          .map(id => oldToNewIds.get(id)).filter(Boolean))];
        if (!ids.length || data.workspaces.length >= 100) continue;
        const baseName = String(item.name || "Imported workspace").trim().slice(0, 65);
        let name = baseName || "Imported workspace";
        if (data.workspaces.some(w => w.name?.toLocaleLowerCase() === name.toLocaleLowerCase())) {
          let suffix = 2;
          const numberedName = n => {
            const ending = ` (${n})`;
            return baseName.slice(0, 65 - ending.length) + ending;
          };
          while (data.workspaces.some(w => w.name?.toLocaleLowerCase() === numberedName(suffix).toLocaleLowerCase())) suffix++;
          name = numberedName(suffix);
        }
        data.workspaces.push({id: crypto.randomUUID(), name, categoryIds: ids});
      }
    }
    await putData(data);
    return {state: data};
  }
  throw new Error("Unknown action.");
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  serial(() => doAction(message)).then(
    result => sendResponse({ok: true, ...result}),
    error => sendResponse({ok: false, error: error?.message || "Something went wrong."})
  );
  return true;
});

async function autoCaptureTab(tabId, windowId) {
  const data = await getData();
  const capture = data.capture;
  if (!capture || capture.windowId !== windowId) return;
  if (Date.now() - capture.startedAt > CAPTURE_MAX_AGE_MS) {
    data.capture = null;
    await putData(data);
    return;
  }
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (!tab || !safeUrl(tab)) return;
  const result = saveIntoCategory(data, capture.categoryId, [tab]);
  if (result.changed) await putData(data); // Avoid unnecessary side-panel re-renders on revisits.
}
chrome.tabs.onActivated.addListener(info => {
  serial(() => autoCaptureTab(info.tabId, info.windowId)).catch(() => {});
});
chrome.tabs.onUpdated.addListener((tabId, change, tab) => {
  if (change.url && tab.active) {
    serial(() => autoCaptureTab(tabId, tab.windowId)).catch(() => {});
  }
});
chrome.commands.onCommand.addListener(command => {
  if (command !== "save-to-last-category") return;
  serial(async () => {
    const data = await getData();
    if (data.lastCategoryId && data.categories.some(c => c.id === data.lastCategoryId)) {
      await addActive(data.lastCategoryId, false);
    }
  }).catch(() => {});
});

// Clicking the pinned toolbar icon opens the persistent side panel.
chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({openPanelOnActionClick: true}).catch(() => {});
});
chrome.runtime.onStartup.addListener(() => {
  chrome.sidePanel.setPanelBehavior({openPanelOnActionClick: true}).catch(() => {});
});
chrome.sidePanel.setPanelBehavior({openPanelOnActionClick: true}).catch(() => {});
