QUICKTAB ORGANIZER v2.2.0 — INSTALLATION + FEATURES
===================================================

IMPORTANT: KEEP A BACKUP BEFORE UPGRADING
-----------------------------------------
1. In your CURRENT QuickTab Organizer, click Export backup and save the JSON.
2. Close the QuickTab side panel.
3. Replace the files in the SAME unpacked-extension folder with the files in
   this quicktab-organizer folder.
4. Open chrome://extensions and click Reload on QuickTab Organizer.
5. Reopen the side panel and verify your category/link totals.

Using the SAME unpacked-extension folder normally preserves the extension ID
and its Chrome local storage. Loading from a new folder can create a different
extension ID with separate storage. If that happens, use Import backup.
Import adds categories; it does not replace existing categories.

FRESH INSTALL (Chrome 116+)
--------------------------
1. Extract QuickTab-Organizer-v2.2.0.zip into a permanent folder.
2. Open chrome://extensions and enable Developer mode.
3. Click Load unpacked and select the quicktab-organizer folder containing
   manifest.json. Do not select the ZIP itself.
4. Pin QuickTab Organizer and click its toolbar icon to open the side panel.

NEW IN v2.2.0
-------------

1. NEW CATEGORY TEXT ALSO SEARCHES
- Anything typed in New category is copied immediately into Search categories
  or links.
- Existing category-name matches and saved-link matches appear before you add
  another category, helping you avoid unnecessary categories.
- You can still edit or clear the Search field directly.
- After a category is created successfully, both fields clear.

2. CLEANER SAVED-LINK SECTIONS
- The button now says Show saved links / Hide saved links.
- Only one category can keep its saved-link section open at a time.
- Opening another category automatically closes the previously open category.
- Link selections are kept when a category is collapsed and reopened.
- Link drag/drop, arrow ordering, renaming, checkboxes, Shift selection,
  Select all, Clear, and Open selected are unchanged.

3. SELECTABLE UNDO / RECYCLE BIN
- The Undo button now opens Deleted items instead of immediately restoring only
  the newest deletion.
- Deleted links, categories, and workspaces are listed newest first.
- Each entry shows its type, name, source category where applicable, deletion
  time, and a Restore button.
- Restore one item directly, or select several and click Restore selected.
- When a deleted category and its individually deleted links are selected
  together, the category is restored first and then the links.
- A category restore includes all links that were inside it when deleted, its
  category position, pin position, and saved-workspace memberships.
- A single-link restore returns the URL, website title, custom name, timestamp,
  and location in its original category. If its category is still deleted,
  restore that category first (or select both and use Restore selected).
- Old v2.1.2 undo entries are automatically given stable history IDs. Existing
  deletion history remains usable after upgrading.
- Undo history remains in chrome.storage.local and survives panel closing,
  extension reloads, and Chrome restarts.

PERMANENT DELETION — NO CONFIRMATION BY DESIGN
- Select entries and click Delete selected to remove only those history items.
- Click Delete on an individual history entry to remove only that entry.
- Click Clear all to empty the entire deletion history.
- These recycle-bin deletion actions intentionally show NO confirmation, as
  requested. They are permanent and cannot themselves be undone.
- The normal confirmation dialogs shown when initially deleting a live link,
  category, or workspace are still retained.

4. COMPACT ALREADY-OPEN MESSAGES
- Opening one saved link that is already open now shows only:
  Already open — switched.
- Bulk results use compact text such as:
  4 opened · 2 already open.
- Optional already-open details stay collapsed until Details is opened.
- The underlying duplicate-tab detection and cross-window tab reuse are
  unchanged.

5. CATEGORY TOTALS INCLUDE PINS
- My categories now shows category count, saved-link count, and pinned count,
  for example: 25 categories · 310 links · 4 pinned.
- Clear pins still only unpins categories; it does not delete anything.

PRESERVED EXISTING FEATURES
---------------------------
- Original QuickTab name, ◫ logo, colors, and side-panel structure.
- Category drag/drop and arrow ordering.
- Saved-link drag/drop and arrow ordering.
- Save + Next.
- Capture tabs with the existing 10-minute safety limit.
- Save highlighted tabs.
- Open all and Open selected.
- Exact-duplicate prevention within a category.
- Custom saved-link names without changing URLs.
- Pin/unpin and Clear pins.
- Saved workspaces, workspace activation, rename, and deletion.
- Smart search ranking: exact category names first, then category-name matches,
  then saved-link matches.
- Export/import backup.
- Alt+Shift+S save-to-last-category shortcut.
- Existing-tab reuse across accessible normal Chrome windows.
- No page scripts, external services, or page refresh requirement.

BACKUP FORMAT, STORAGE, AND PRIVACY
----------------------------------
- v1, v2, v2.1, and v2.1.2 category/link data remains readable.
- Exported backups contain the current categories, custom link names, ordering,
  pinnedCategoryIds, and workspaces.
- Deletion history is intentionally not exported; the backup represents the
  current live library.
- Data stays in this Chrome profile's extension-local storage.
- Permissions are unchanged: tabs, storage, and sidePanel.

See TESTING.txt for the post-upgrade checklist. Keep your previous extension
folder and JSON backup until the upgraded version has been verified in Chrome.
