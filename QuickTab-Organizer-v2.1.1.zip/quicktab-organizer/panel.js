// QuickTab Organizer v2.1.1 — accessible local side-panel UI.
const categoriesEl = document.getElementById("categories");
const statusEl = document.getElementById("status");
const bannerEl = document.getElementById("captureBanner");
const totalEl = document.getElementById("total");
const feedbackEl = document.getElementById("openFeedback");
const searchInput = document.getElementById("searchCategories");
const searchClear = document.getElementById("clearSearch");
const workspacesEl = document.getElementById("workspaces");
const saveWorkspaceBtn = document.getElementById("saveWorkspace");
let state = {categories: [], capture: null, pinnedCategoryIds: [], workspaces: []};
const expanded = new Set();
const selections = new Map(); // Category id -> selected URL Set; survives storage refreshes.
const selectAnchors = new Map(); // Category id -> last normal-clicked URL.
let dragInfo = null;
let deferredRender = false;
let busy = false;

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text; // Never inject saved titles/URLs as HTML.
  return node;
}
function btn(label, cls, fn, title) {
  const b = el("button", cls || "", label);
  b.type = "button";
  if (title) { b.title = title; b.setAttribute("aria-label", title); }
  b.addEventListener("click", fn);
  return b;
}
function status(text, error = false) {
  statusEl.textContent = text;
  statusEl.classList.toggle("error", error);
}
function message(type, extra = {}) {
  return chrome.runtime.sendMessage({type, ...extra}).then(response => {
    if (!response?.ok) throw new Error(response?.error || "The operation failed.");
    return response;
  });
}
async function work(label, operation, onSuccess) {
  if (busy) return;
  busy = true;
  try {
    const result = await operation();
    if (result?.state) state = result.state;
    await refresh();
    if (onSuccess) onSuccess(result);
    status(typeof label === "function" ? label(result) : label);
  } catch (err) { status(err?.message || "Operation failed.", true); }
  finally { busy = false; }
}
async function refresh() {
  try {
    state = (await message("getState")).state;
    if (dragInfo) deferredRender = true;
    else render();
  } catch (err) { status(err.message, true); }
}
function clearOpenFeedback() {
  feedbackEl.replaceChildren();
  feedbackEl.hidden = true;
}
function summarizeOpen(result) {
  clearOpenFeedback();
  const existing = Array.isArray(result?.existing) ? result.existing : [];
  const failed = Array.isArray(result?.failed) ? result.failed : [];
  if (!existing.length && !failed.length) return;
  feedbackEl.hidden = false;
  const header = el("div", "feedback-heading");
  const title = el("strong", "", existing.length
    ? `${existing.length} already-open ${existing.length === 1 ? "tab" : "tabs"}`
    : "Some tabs could not be opened");
  header.append(title, btn("×", "small", clearOpenFeedback, "Dismiss opening results"));
  feedbackEl.append(header);
  if (existing.length) {
    feedbackEl.append(el("p", "feedback-description", result.focused
      ? "That site was already open, so QuickTab switched to its existing tab."
      : "These sites were not opened again. Select Go to tab to switch to an existing tab."));
    const matches = el("div", "matched-tabs");
    for (const match of existing) {
      const row = el("div", "matched-tab");
      const info = el("div", "matched-info");
      const name = el("strong", "matched-title", match.title || match.url);
      name.title = match.url;
      const location = match.windowNumber
        ? `Window ${match.windowNumber} · Tab ${match.tabIndex}`
        : `Tab ${match.tabIndex}`;
      info.append(name, el("span", "matched-location", location));
      row.append(info, btn("Go to tab ↗", "small primary", () => {
        work("Switched to the already-open tab.", () => message("focusExisting", {tabId: match.tabId, url: match.url}));
      }, `Go to already-open tab ${match.tabIndex}`));
      matches.append(row);
    }
    feedbackEl.append(matches);
  }
  if (failed.length) {
    feedbackEl.append(el("p", "feedback-error", `${failed.length} tab(s) could not be opened.`));
    for (const failure of failed.slice(0, 5)) {
      feedbackEl.append(el("p", "failed-url", `${failure.url}: ${failure.reason}`));
    }
  }
}
function openStatus(result) {
  const existing = result.existing?.length || 0;
  const failures = result.failed?.length || 0;
  if (result.focused) return "Already open — switched to its existing Chrome tab.";
  const pieces = [`${result.opened || 0} new ${result.opened === 1 ? "tab" : "tabs"} opened`];
  if (existing) pieces.push(`${existing} already open (not duplicated)`);
  if (failures) pieces.push(`${failures} failed`);
  return pieces.join(" · ") + ".";
}
function openAction(type, id, urls) {
  const extra = {id};
  if (urls) extra.urls = urls;
  return work(openStatus, () => message(type, extra), summarizeOpen);
}
function openSingle(catId, url) {
  return work(openStatus, () => message("openOne", {id: catId, url}), summarizeOpen);
}
function selectionFor(catId) {
  if (!selections.has(catId)) selections.set(catId, new Set());
  return selections.get(catId);
}
function onSelectionClick(event, cat, link, list, countLabel) {
  const chosen = selectionFor(cat.id);
  const checked = event.currentTarget.checked;
  const anchorUrl = selectAnchors.get(cat.id);
  const from = anchorUrl === undefined ? -1 : cat.links.findIndex(l => l.url === anchorUrl);
  const to = cat.links.findIndex(l => l.url === link.url);
  if (event.shiftKey && from >= 0 && to >= 0) {
    for (let i = Math.min(from, to); i <= Math.max(from, to); i++) {
      if (checked) chosen.add(cat.links[i].url);
      else chosen.delete(cat.links[i].url);
    }
  } else {
    if (checked) chosen.add(link.url);
    else chosen.delete(link.url);
    selectAnchors.set(cat.id, link.url);
  }
  syncSelection(list, chosen, countLabel);
}
function syncSelection(list, chosen, countLabel) {
  list.querySelectorAll(".link-check").forEach(input => {
    input.checked = chosen.has(input.value);
    input.closest(".link-row")?.classList.toggle("selected", input.checked);
  });
  countLabel.textContent = `${chosen.size} selected`;
}
function categoryIds() {
  return new Set((state.categories || []).map(c => c.id));
}
function pinnedIds() {
  const ids = categoryIds();
  return [...new Set((state.pinnedCategoryIds || []).filter(id => ids.has(id)))];
}
function normalized(text) {
  return String(text || "").normalize("NFKD").toLocaleLowerCase()
    .replace(/[\u0300-\u036f]/g, "").replace(/[^\p{L}\p{N}]/gu, "");
}
// Search ranking: category names always win over matches inside their saved links.
// Exact name > name starts with query > name contains query > matching link title.
// Kept entirely in the panel: it never mutates the stored category order.
function searchMatchRank(cat, query) {
  const compact = normalized(query);
  if (!compact) return 0;
  const terms = query.trim().toLocaleLowerCase().split(/\s+/).map(normalized).filter(Boolean);
  function rank(text, base) {
    const value = normalized(text);
    if (!value) return Number.POSITIVE_INFINITY;
    if (value === compact) return base;
    if (value.startsWith(compact)) return base + 1;
    if (value.includes(compact) || (terms.length > 1 && terms.every(term => value.includes(term)))) return base + 2;
    return Number.POSITIVE_INFINITY;
  }
  let best = rank(cat.name, 0);
  if (best === 0) return best;
  for (const link of (cat.links || [])) {
    best = Math.min(best, rank(link.customName || "", 3), rank(link.title || "", 3));
  }
  return best;
}
function matchesSearch(cat, query) {
  return Number.isFinite(searchMatchRank(cat, query));
}
function moveCategory(catId, direction) {
  if (searchInput.value.trim()) return;
  const ids = pinnedIds();
  const pinned = ids.includes(catId);
  const list = pinned ? ids : state.categories.filter(c => !ids.includes(c.id)).map(c => c.id);
  const index = list.indexOf(catId);
  const other = list[index + direction];
  if (!other) return;
  return work("Category order saved.", () => message(pinned ? "reorderPinnedCategory" : "reorderCategory", {
    sourceId: catId, targetId: other, placement: direction < 0 ? "before" : "after"
  }));
}
function pinCategory(catId, pinned) {
  return work(pinned ? "Category pinned." : "Category unpinned.",
    () => message("setCategoryPinned", {id: catId, pinned}));
}
function renderWorkspaces() {
  workspacesEl.replaceChildren();
  const pins = pinnedIds();
  saveWorkspaceBtn.disabled = pins.length === 0;
  saveWorkspaceBtn.title = pins.length ? `Save ${pins.length} pinned categories as a workspace` : "Pin categories before saving a workspace";
  const workspaces = Array.isArray(state.workspaces) ? state.workspaces : [];
  for (const workspace of workspaces) {
    const valid = new Set(categoryIds());
    const ids = (workspace.categoryIds || []).filter(id => valid.has(id));
    if (!ids.length) continue;
    const item = el("div", "workspace-item");
    const isCurrent = ids.length === pins.length && ids.every((id, i) => pins[i] === id);
    item.classList.toggle("current", isCurrent);
    const load = btn(`${workspace.name} · ${ids.length}`, "workspace-load", () => {
      work(`Workspace: ${workspace.name}`, () => message("activateWorkspace", {id: workspace.id}), () => {
        searchInput.value = ""; // Loading a workspace always reveals its pinned categories.
        render();
      });
    }, `Pin categories from workspace ${workspace.name}`);
    if (isCurrent) load.setAttribute("aria-current", "true");
    item.append(load);
    item.append(btn("✎", "workspace-edit", () => {
      const name = prompt("Workspace name:", workspace.name);
      if (name !== null && name.trim() && name.trim() !== workspace.name) {
        work("Workspace renamed.", () => message("renameWorkspace", {id: workspace.id, name}));
      }
    }, `Rename workspace ${workspace.name}`));
    item.append(btn("×", "workspace-remove", () => {
      if (confirm(`Delete workspace "${workspace.name}"? Your saved categories and links will not be deleted.`)) {
        work("Workspace deleted.", () => message("removeWorkspace", {id: workspace.id}));
      }
    }, `Delete workspace ${workspace.name}`));
    workspacesEl.append(item);
  }
  workspacesEl.hidden = !workspacesEl.childElementCount;
}
function addSectionHeading(label, count, clearable = false) {
  const heading = el("div", "category-group-heading");
  heading.append(el("strong", "", `${label} · ${count}`));
  if (clearable) heading.append(btn("Clear pins", "small", () => work("Categories unpinned.", () => message("clearPinnedCategories"))));
  categoriesEl.append(heading);
}
function moveLink(cat, link, direction) {
  const index = cat.links.findIndex(l => l.url === link.url);
  const other = cat.links[index + direction];
  if (!other) return;
  return work("Link order saved.", () => message("reorderLink", {
    id: cat.id, sourceUrl: link.url, targetUrl: other.url,
    placement: direction < 0 ? "before" : "after"
  }));
}
function dragStart(event, info, node) {
  dragInfo = info;
  deferredRender = false;
  event.dataTransfer.effectAllowed = "move";
  event.dataTransfer.setData("text/plain", "QuickTab Organizer reorder");
  node.classList.add("dragging");
}
function dragEnd() {
  dragInfo = null;
  document.querySelectorAll(".dragging,.drop-before,.drop-after").forEach(node => {
    node.classList.remove("dragging", "drop-before", "drop-after");
  });
  if (deferredRender) { deferredRender = false; render(); }
}
function placementAt(event, node) {
  const bounds = node.getBoundingClientRect();
  return event.clientY < bounds.top + bounds.height / 2 ? "before" : "after";
}
function showDropMarker(node, placement) {
  node.classList.toggle("drop-before", placement === "before");
  node.classList.toggle("drop-after", placement === "after");
}
function dragScroll(event, scrollContainer) {
  const margin = 44;
  if (scrollContainer && scrollContainer.scrollHeight > scrollContainer.clientHeight) {
    const bounds = scrollContainer.getBoundingClientRect();
    if (event.clientY < bounds.top + margin) scrollContainer.scrollTop -= 17;
    else if (event.clientY > bounds.bottom - margin) scrollContainer.scrollTop += 17;
  }
  // Keep reordering possible when categories are farther down the side panel.
  if (event.clientY < margin) window.scrollBy(0, -17);
  else if (event.clientY > window.innerHeight - margin) window.scrollBy(0, 17);
}
function addCategoryDrag(root, heading, handle, cat) {
  handle.draggable = !searchInput.value.trim();
  if (!handle.draggable) handle.title = "Clear search to reorder categories";
  handle.addEventListener("dragstart", event => {
    if (searchInput.value.trim()) {event.preventDefault(); return;}
    dragStart(event, {kind: "category", id: cat.id, pinned: pinnedIds().includes(cat.id)}, root);
  });
  handle.addEventListener("dragend", dragEnd);
  root.addEventListener("dragover", event => {
    if (dragInfo?.kind !== "category" || dragInfo.id === cat.id ||
        dragInfo.pinned !== pinnedIds().includes(cat.id)) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = "move";
    dragScroll(event);
    showDropMarker(root, event.clientY < heading.getBoundingClientRect().top + heading.getBoundingClientRect().height / 2 ? "before" : "after");
  });
  root.addEventListener("dragleave", event => {
    if (!root.contains(event.relatedTarget)) root.classList.remove("drop-before", "drop-after");
  });
  root.addEventListener("drop", event => {
    if (dragInfo?.kind !== "category" || dragInfo.pinned !== pinnedIds().includes(cat.id)) return;
    event.preventDefault();
    const source = dragInfo.id;
    const pinned = dragInfo.pinned;
    const placement = root.classList.contains("drop-before") ? "before" : "after";
    dragEnd();
    if (source !== cat.id) {
      work("Category order saved.", () => message(pinned ? "reorderPinnedCategory" : "reorderCategory", {sourceId: source, targetId: cat.id, placement}));
    }
  });
}
function addLinkDrag(row, handle, cat, link) {
  handle.draggable = true;
  handle.addEventListener("dragstart", event => {
    event.stopPropagation();
    dragStart(event, {kind: "link", categoryId: cat.id, url: link.url}, row);
  });
  handle.addEventListener("dragend", dragEnd);
  row.addEventListener("dragover", event => {
    if (dragInfo?.kind !== "link" || dragInfo.categoryId !== cat.id || dragInfo.url === link.url) return;
    event.stopPropagation();
    event.preventDefault();
    event.dataTransfer.dropEffect = "move";
    dragScroll(event, row.parentElement);
    showDropMarker(row, placementAt(event, row));
  });
  row.addEventListener("dragleave", event => {
    if (!row.contains(event.relatedTarget)) row.classList.remove("drop-before", "drop-after");
  });
  row.addEventListener("drop", event => {
    if (dragInfo?.kind !== "link") return;
    event.stopPropagation();
    if (dragInfo.categoryId !== cat.id) return; // Never move links between categories.
    event.preventDefault();
    const sourceUrl = dragInfo.url;
    const placement = row.classList.contains("drop-before") ? "before" : "after";
    dragEnd();
    if (sourceUrl !== link.url) {
      work("Link order saved.", () => message("reorderLink", {id: cat.id, sourceUrl, targetUrl: link.url, placement}));
    }
  });
}
function render() {
  categoriesEl.replaceChildren();
  const cats = Array.isArray(state.categories) ? state.categories : [];
  const count = cats.reduce((n, c) => n + c.links.length, 0);
  totalEl.textContent = `${cats.length} categories · ${count} links`;
  const query = searchInput.value;
  searchClear.hidden = !query;
  renderWorkspaces();
  bannerEl.replaceChildren();
  if (state.capture) {
    const active = cats.find(c => c.id === state.capture.categoryId);
    bannerEl.hidden = false;
    bannerEl.append(el("strong", "", `● CAPTURING: ${active?.name || "Unknown"}`));
    bannerEl.append(btn("Stop capturing", "", () => work("Capture stopped.", () => message("stopCapture"))));
  } else bannerEl.hidden = true;
  if (!cats.length) {
    categoriesEl.append(el("div", "empty", "No categories yet."));
    return;
  }
  const ids = categoryIds();
  for (const id of selections.keys()) if (!ids.has(id)) {selections.delete(id); selectAnchors.delete(id); expanded.delete(id);}
  const pinned = pinnedIds();
  const pinnedSet = new Set(pinned);
  const byId = new Map(cats.map(cat => [cat.id, cat]));
  if (query.trim() && normalized(query)) {
    // Search results are relevance-ordered, regardless of where a category
    // appears in a long stored list or whether a nonmatching-name category is pinned.
    const ranked = cats.map((cat, originalIndex) => ({
      cat, originalIndex, rank: searchMatchRank(cat, query), pinnedIndex: pinned.indexOf(cat.id)
    })).filter(item => Number.isFinite(item.rank));
    ranked.sort((a, b) => a.rank - b.rank ||
      Number(b.pinnedIndex >= 0) - Number(a.pinnedIndex >= 0) ||
      (a.pinnedIndex >= 0 && b.pinnedIndex >= 0 ? a.pinnedIndex - b.pinnedIndex : a.originalIndex - b.originalIndex));
    if (!ranked.length) {
      categoriesEl.append(el("div", "empty", "No matching categories."));
      return;
    }
    addSectionHeading("Matches", ranked.length);
    const results = ranked.map(item => item.cat);
    results.forEach((cat, index) => renderCategory(cat, index, results));
    return;
  }
  const pinnedCats = pinned.map(id => byId.get(id)).filter(Boolean);
  const otherCats = cats.filter(cat => !pinnedSet.has(cat.id));
  if (pinnedCats.length) {
    addSectionHeading("Pinned", pinnedCats.length, true);
    pinnedCats.forEach((cat, index) => renderCategory(cat, index, pinnedCats));
  }
  if (otherCats.length) {
    if (pinnedCats.length) addSectionHeading("Other categories", otherCats.length);
    otherCats.forEach((cat, index) => renderCategory(cat, index, otherCats));
  }
}
function renderCategory(cat, index, group) {
  const active = state.capture?.categoryId === cat.id;
  const root = el("article", `category${active ? " active" : ""}`);
  root.dataset.categoryId = cat.id;
  const heading = el("div", "cat-heading");
  const handle = el("span", "drag-handle cat-drag-handle", "⠿");
  handle.title = "Drag to reorder category";
  handle.setAttribute("aria-label", "Drag to reorder category");
  const label = el("div", "cat-title", cat.name);
  label.append(el("span", "count", `${cat.links.length}`));
  heading.append(handle, label);
  const opts = el("div", "cat-head-actions");
  const isPinned = pinnedIds().includes(cat.id);
  const pin = btn("📌", `small pin-btn${isPinned ? " is-pinned" : ""}`,
    () => pinCategory(cat.id, !isPinned), `${isPinned ? "Unpin" : "Pin"} ${cat.name}`);
  pin.setAttribute("aria-pressed", String(isPinned));
  const up = btn("↑", "small order-btn", () => moveCategory(cat.id, -1), "Move category up");
  up.disabled = index === 0 || !!searchInput.value.trim();
  const down = btn("↓", "small order-btn", () => moveCategory(cat.id, 1), "Move category down");
  down.disabled = index === group.length - 1 || !!searchInput.value.trim();
  opts.append(pin, up, down);
  opts.append(btn("Rename", "small", () => {
    const name = prompt("New category name:", cat.name);
    if (name !== null && name.trim()) work("Category renamed.", () => message("renameCategory", {id: cat.id, name}));
  }));
  opts.append(btn("×", "small danger", () => {
    if (confirm(`Delete the category "${cat.name}" and its ${cat.links.length} saved links?`)) {
      work("Category removed.", () => message("removeCategory", {id: cat.id}));
    }
  }, `Delete category ${cat.name}`));
  heading.append(opts);
  root.append(heading);
  addCategoryDrag(root, heading, handle, cat);

  const actions = el("div", "actions");
  const saveLabel = result => result.result?.added
    ? `Saved ${result.result.added} new link to ${cat.name}; moved to next tab.`
    : "URL already saved in this category; moved to next tab.";
  actions.append(btn("Save + Next →", "save", () => work(saveLabel, () => message("saveAndNext", {id: cat.id}))));
  actions.append(btn(active ? "■ Stop Capture" : "● Capture tabs", `capture${active ? " recording" : ""}`,
    () => work(active ? "Capture stopped." : `Capturing ${cat.name}. Switch Chrome tabs now.`, () => message(active ? "stopCapture" : "startCapture", {id: cat.id}))));
  actions.append(btn("Open all ↗", "open", () => {
    if (cat.links.length > 40 && !confirm(`Open up to ${cat.links.length} Chrome tabs at once? Already-open links will be skipped.`)) return;
    openAction("openAll", cat.id);
  }));
  actions.append(btn("Save highlighted", "", () => work(result => {
    const r = result.result || {};
    return `${r.added || 0} new link(s) saved; ${r.already || 0} already in ${cat.name}.`;
  }, () => message("saveHighlighted", {id: cat.id}))));
  root.append(actions);
  const details = el("div", "details");
  const toggle = btn(expanded.has(cat.id) ? "▴ Hide saved links" : "▾ Show saved links / select some", "", () => {
    if (expanded.has(cat.id)) expanded.delete(cat.id);
    else expanded.add(cat.id);
    render();
  });
  toggle.style.width = "100%";
  details.append(toggle);
  if (expanded.has(cat.id)) renderLinks(cat, details);
  root.append(details);
  categoriesEl.append(root);
}
function renderLinks(cat, details) {
  if (!cat.links.length) details.append(el("p", "", "No links saved here yet."));

  const list = el("div", "link-list");
  const chosen = selectionFor(cat.id);
  const urls = new Set(cat.links.map(link => link.url));
  for (const url of chosen) if (!urls.has(url)) chosen.delete(url);
  if (!urls.has(selectAnchors.get(cat.id))) selectAnchors.delete(cat.id);
  const countLabel = el("span", "selected-count", `${chosen.size} selected`);
  for (let i = 0; i < cat.links.length; i++) {
    const link = cat.links[i];
    const row = el("div", "link-row");
    row.dataset.url = link.url;
    const handle = el("span", "drag-handle link-drag-handle", "⠿");
    handle.title = "Drag link to reorder";
    const check = el("input");
    check.type = "checkbox";
    check.className = "link-check";
    check.value = link.url;
    check.checked = chosen.has(link.url);
    check.setAttribute("aria-label", `Select ${link.customName || link.title || link.url}`);
    check.addEventListener("click", event => onSelectionClick(event, cat, link, list, countLabel));
    const copy = el("div", "link-copy");
    const title = btn(link.customName || link.title || link.url, "link-title", () => openSingle(cat.id, link.url), `Open or switch to ${link.customName || link.title || link.url}`);
    title.title = link.url;
    copy.append(title, el("span", "link-url", link.url));
    const tools = el("div", "link-tools");
    const up = btn("↑", "small order-btn link-arrow", () => moveLink(cat, link, -1), "Move link up");
    up.disabled = i === 0;
    const down = btn("↓", "small order-btn link-arrow", () => moveLink(cat, link, 1), "Move link down");
    down.disabled = i === cat.links.length - 1;
    tools.append(up, down);
    tools.append(btn("✎", "small rename-link", () => {
      const name = prompt("Custom name for this saved URL (leave blank to use the website title):", link.customName || "");
      if (name !== null) {
        work(name.trim() ? "Custom name saved. URL unchanged." : "Custom name cleared; website title restored.",
          () => message("renameLink", {id: cat.id, url: link.url, name}));
      }
    }, `Rename ${link.customName || link.title || link.url}`));
    tools.append(btn("×", "small danger", () => work("Saved link removed.", () => message("removeLink", {id: cat.id, url: link.url})), `Remove ${link.customName || link.title || link.url}`));
    row.append(handle, check, copy, tools);
    row.classList.toggle("selected", check.checked);
    addLinkDrag(row, handle, cat, link);
    list.append(row);
  }
  details.append(list);
  if (cat.links.length) {
    const opts = el("div", "selected-buttons");
    const all = btn("Select all", "small", () => {
      cat.links.forEach(l => chosen.add(l.url));
      syncSelection(list, chosen, countLabel);
    });
    const clear = btn("Clear", "small", () => {
      chosen.clear();
      selectAnchors.delete(cat.id);
      syncSelection(list, chosen, countLabel);
    });
    opts.append(all, clear, btn("Open selected ↗", "primary small", () => {
      const urlsToOpen = cat.links.filter(l => chosen.has(l.url)).map(l => l.url);
      if (!urlsToOpen.length) return status("Tick one or more links first.", true);
      if (urlsToOpen.length > 40 && !confirm(`Open up to ${urlsToOpen.length} Chrome tabs at once? Already-open links will be skipped.`)) return;
      openAction("openSelected", cat.id, urlsToOpen);
    }));
    details.append(opts, countLabel);
  }
}

searchInput.addEventListener("input", render);
// Enter jumps to the first visible match; filtering itself is instant while typing.
searchInput.addEventListener("keydown", event => {
  if (event.key !== "Enter") return;
  event.preventDefault();
  categoriesEl.querySelector(".category")?.scrollIntoView({block: "nearest"});
});
searchClear.addEventListener("click", () => {
  searchInput.value = "";
  render();
  searchInput.focus();
});
saveWorkspaceBtn.addEventListener("click", () => {
  if (!pinnedIds().length) return status("Pin categories first.", true);
  const name = prompt("Save workspace as:");
  if (name !== null && name.trim()) {
    work("Workspace saved.", () => message("createWorkspace", {name}));
  }
});
document.getElementById("addForm").addEventListener("submit", event => {
  event.preventDefault();
  const field = document.getElementById("categoryName");
  const name = field.value.trim();
  if (!name) return;
  work(`Created ${name}.`, () => message("createCategory", {name}));
  field.value = "";
});
document.getElementById("exportBtn").addEventListener("click", async () => {
  try {
    const data = (await message("getState")).state;
    const backup = JSON.stringify({
      exportedAt: new Date().toISOString(),
      categories: data.categories,
      pinnedCategoryIds: data.pinnedCategoryIds || [],
      workspaces: data.workspaces || []
    }, null, 2);
    const blob = new Blob([backup], {type: "application/json"});
    const url = URL.createObjectURL(blob);
    const anchor = el("a");
    anchor.href = url;
    anchor.download = `quicktab-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.append(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
    status("Backup exported.");
  } catch (err) { status(`Cannot export: ${err.message}`, true); }
});
document.getElementById("importBtn").addEventListener("click", () => document.getElementById("importFile").click());
document.getElementById("importFile").addEventListener("change", async event => {
  const file = event.target.files?.[0];
  if (!file) return;
  try {
    if (file.size > 5_000_000) throw new Error("Backup exceeds 5 MB.");
    const data = JSON.parse(await file.text());
    await work("Backup imported as new categories; existing categories kept.", () => message("importData", {data}));
  } catch (err) { status(`Cannot import: ${err.message}`, true); }
  event.target.value = "";
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.quicktabData) {
    state = changes.quicktabData.newValue || {categories: [], capture: null};
    if (dragInfo) deferredRender = true;
    else render();
  }
});
refresh();
