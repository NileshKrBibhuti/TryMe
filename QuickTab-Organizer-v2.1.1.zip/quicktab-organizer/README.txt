QUICKTAB ORGANIZER v2.1.1 — INSTALLATION + FEATURES
===================================================

IMPORTANT: KEEP A BACKUP BEFORE UPGRADING
-----------------------------------------
1. In your CURRENT QuickTab Organizer, click Export backup. Save the JSON.
2. Close the QuickTab side panel.
3. Replace the original extension's files with the files in the new
   quicktab-organizer folder. Keep the SAME unpacked-extension folder/path.
4. Open chrome://extensions and click Reload on QuickTab Organizer.
5. Reopen the side panel. Verify that category/link totals still match.

DO NOT uninstall the old extension before making a backup.
If you load the unpacked extension from a NEW folder, Chrome may assign it a
DIFFERENT extension ID. A new ID has separate storage; it can look empty even
though the original extension still has your saved data. Use Import backup
to COPY categories into a separately installed extension if needed.
Imports ADD categories. They do not replace existing ones.

FRESH INSTALL (Chrome 116+)
--------------------------
1. Extract QuickTab-Organizer-v2.1.1.zip into a permanent folder.
2. Visit chrome://extensions and turn on Developer mode.
3. Click Load unpacked and select the quicktab-organizer FOLDER containing
   manifest.json (not the ZIP file itself).
4. Pin QuickTab Organizer from the Chrome Extensions menu and click the
   toolbar button to open the side panel.

FIXED IN v2.1.1
---------------
- Searching "chat" now puts a category named exactly "chat" first, followed
  by category-name matches such as "ChatGPT" and "ChatMax".
- Categories matching only because they contain a saved link with "chat" in
  its title appear after all matching category names.
- Search still filters instantly, regardless of case, spaces, or hyphens.
  Enter simply scrolls to the first result and never creates a category.
- Searching does not change the saved category order, pinned categories,
  workspaces, links, or any Chrome tab behavior. Clear search to restore order.

FEATURES FROM v2.1
------------------
SMART SEARCH
- Search directly below Add category. Results filter instantly.
- Upper/lower case, spaces, and punctuation do not affect matching:
  "CHAT gPt", "chatgpt", and "Chat-GPT" all match "ChatGPT".
- Partial search matches; saved link names and website titles can also
  reveal their containing category.
- Click the X in the search field to show all categories again.
- Clear the search before rearranging categories; reordering controls are
  disabled while search filters the visible list.

PIN / UNPIN
- Each category header has a pin button (pushpin icon).
- Pinning brings the category into the Pinned group at the TOP; no manual
  dragging through hundreds of categories is needed.
- Pinned categories remain pinned until you unpin or clear them, including
  after reopening Chrome. Pinned categories can be reordered within the
  Pinned group using the arrows or drag handles.
- Click the pin button again to unpin one category, or click Clear pins to
  unpin all. The underlying original category order does not change.
- Pinned and unpinned categories use the same original four actions.

WORKSPACES
- Pin the categories you need, then click Workspaces > + Save. Type a name
  such as "Morning Work". This stores a snapshot of those category choices.
- Later, click that saved workspace to bring its group of categories to the
  top again. Loading a workspace REPLACES the current pinned group, but it
  does not delete, duplicate or move any saved categories or URLs.
- Workspaces persist after the side panel closes; click pencil to rename or
  X to delete a saved workspace (with confirmation). Deleting a workspace
  never deletes its categories, links or current pins.
- Removing a category cleans its references from saved workspaces.
- Save and import JSON backups to preserve both pins and workspaces. During
  import, category IDs are safely regenerated and workspace IDs remapped.

CLEANER UI
- Retained the original QuickTab logo, colors, buttons and functional labels.
- Removed extra header slogans, intro paragraph and footer explanations.

YOUR EXISTING v2 FEATURES ARE STILL HERE
----------------------------------------
- Save + Next: save current URL and switch to the next eligible Chrome tab.
- Capture tabs: automatically collect websites you visit or activate in
  that Chrome window, with the existing 10-minute safety limit.
- Save highlighted: save multiple highlighted Chrome tabs together.
- Open all: open not-already-open URLs in a category.
- Custom names for URLs, independent in each category. Website URL unchanged.
- Newly added URLs appear first; exact duplicates in one category skipped.
- Drag/drop or use arrows to rearrange links and unpinned categories.
- Shift-click checkbox range selection; Select all, Clear, Open selected.
- Reuse already-open browser tabs across accessible normal Chrome windows.
  Existing matches are displayed with Go to tab buttons; a single link
  click can focus an already-open tab.
- Backup export/import, category renaming, deletion confirmation, counts,
  and Alt+Shift+S shortcut for saving to your last-used category.

BACKUP FORMAT + PRIVACY
-----------------------
- Existing v1 and v2 stored categories/links remain readable without a
  migration or reset. v2 and older JSON exports remain importable.
- v2.1 exports include categories, link custom names and manual ordering,
  pinnedCategoryIds and workspaces. Import is additive and remaps IDs.
- Categories/links are stored ONLY in this Chrome profile's extension-local
  storage, not on an external server. No network service or page scripts.
- Incognito tabs and other Chrome profiles aren't accessible unless Chrome
  specifically permits extension access to them.
- Permissions unchanged: tabs, storage and sidePanel.

See TESTING.txt for the post-upgrade checklist. Keep your old backup until
all key actions work as expected in your own Chrome profile.
